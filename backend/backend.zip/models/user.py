from db import db

class UserModel(db.Model):
    __tablename__ = 'User'

    idUser = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False)
    loginCount = db.Column(db.Integer)
    passwordSalt = db.Column(db.String(20))
    passwordHash = db.Column(db.String(120))

    # override constructor
    def __init__(self, idUser, username, passwordSalt, passwordHash):
        self.idUser = idUser
        self.username = username
        self.loginCount = 0
        self.passwordSalt = passwordSalt
        self.passwordHash = passwordHash

    def __repr__(self):
        return '<User %r>' % self.username

    def json(self):
        return {
            'idUser': self.idUser, 
            'username': self.username,
            'loginCount': self.loginCount }

    @classmethod
    def find_by_username(cls, username):
        return cls.query.filter_by(username=username).first()

    @classmethod
    def find_by_id(cls, _id):
        return cls.query.filter_by(idUser=_id).first()