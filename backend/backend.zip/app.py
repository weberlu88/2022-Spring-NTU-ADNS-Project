from flask import Flask
from flask_restful import Resource, Api
from flask_cors import CORS, cross_origin
from flask import render_template

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:./database.db'
app.secret_key = 'keyyyyyyyy'
app.config['CORS_HEADERS'] = 'Content-Type'
api = Api(app)

# class SearchOrder(Resource): 
#     @cross_origin()   
#     def get(self, customer_name=None):
#         # Get all orders / Search for customer's order'
#         orders = OrderModel.get_all_orders(customer_name)
#         print(orders)
#         return {'orders': orders}

# class OrderDetail(Resource):
#     @cross_origin() 
#     def get(self, order_id):
#         res = OrderModel.get_order_detail(order_id)
#         return {'detail': res}

# api.add_resource(SearchOrder, '/api/search', endpoint="all_orders")
# api.add_resource(SearchOrder, '/api/search/<string:customer_name>', endpoint="search_orders")
# api.add_resource(OrderDetail, '/api/order_detail/<int:order_id>')
# http://localhost:5000/api/search
# http://localhost:5000/api/search/steve
# http://localhost:5000/api/order_detail/17

if __name__ == "__main__":
    from db import db
    db.init_app(app)
    app.run(host = '127.0.0.1', port = 5000, debug = True)